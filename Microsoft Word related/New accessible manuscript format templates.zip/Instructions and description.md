# Template guide and overview.

These templates were adapted by [Robert Kingett](http://blindjournalist.wordpress.com/) and made to be used on more modern computers.

These templates were adapted from [Shun's templates.](https://www.shunn.net/format/templates.html) but my templates rely on more fields and less macros, and makes some aspects easier for keyboard users by automating some of the process, such as creating a new chapter.

These templates all make use of [fields and field codes](https://support.microsoft.com/en-us/office/insert-edit-and-view-fields-in-word-c429bbb0-8669-48a7-bd24-bab6ba6b06bb?ui=en-US&rs=en-US&ad=US) to provide an almost automated experience. The macro enabled templates provide some extra functionality but the field codes will work without the macros.

The field codes contained in these templates will automatically change when a user updates the fields with F9. Here are the field codes and what they do.

1. Rounded word count. I created a field that would automatically count and round words to the nearest hundred or nearest thousand, depending if you're working with novels or short stories.
2. Title of work. Changes the title in the document header and in the body to match the title of the document entered in [document properties](https://support.microsoft.com/en-us/office/view-or-change-the-properties-for-an-office-file-21d604c2-481e-4379-8e54-1dd4622c6b75).

## How to update the fields manually.

If you're using the templates that do not contain macros, you will need to update all of the fields before closing the document. To do this,

1. Press Control A to select the whole document.
2. Press F9.
3. Press Control S to save the document and the newly changed fields.

## What do the macros do?

As of right now, I have created four macros. Not all macros are included in every template. Below, you can get an overview of the macros created and what they do.

1. Create a new chapter. For the Novel template.
2. Create a new chapter with title. For the novel template.
3. Automatically updates all fields in the document, including header, For all templates with macros. It saves the document, then closes Word.
4. Scene break. For all templates with macros. Creates a centered line with three asterisks then creates a new line, left aligned, ready for you to start typing again.

## Macro keyboard commands.

These will not work on the templates without macros.

1. Alt C inserts a page break, then creates a new chapter number, then starts you off on the next paragraph automatically.
2. Alt T creates a page break, creates a chapter number, then creates a chapter name, then puts your cursor in the perfect position for writing.